import React, { Component } from "react";
export class About extends Component {
  render() {
    return (
      <div>
        <h3>About page of the Student Management Portal</h3>
      </div>
    );
  }
}

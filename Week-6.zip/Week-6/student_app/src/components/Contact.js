import React, { Component } from "react";
export class Contact extends Component {
  render() {
    return (
      <div>
        <h3>Contact page of the Student Management Portal</h3>
      </div>
    );
  }
}

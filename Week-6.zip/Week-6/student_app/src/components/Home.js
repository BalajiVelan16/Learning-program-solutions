import React, { Component } from "react";
export class Home extends Component {
  render() {
    return (
      <div>
        <h3>Home page of the Student Management Portal</h3>
      </div>
    );
  }
}
